# Harness²：显式的游戏方法练习与经验积累

核心从 `0.5.7-rc.54` 提供 `Harness2Runner`（`agent-mc-world/decisions`）、`MethodPracticeExecutor`、`createPhysicsMethodPractice`、`createPracticeGameMemory`（`agent-mc-world/learning`）。导入不会连接游戏、请求模型、训练权重或采用技能。

集成使用 Google 原版 Harness² 的 Propose–Probe–Compose、并行/串行递归、选择和反思，固定到 [1cfe254e](https://github.com/google-research/harness2/tree/1cfe254e8d25b15f37048c3730134686abe60335)。这不是权重训练；改变的是有版本的动作程序、参数和使用说明。宿主仍然提供模型、人格、个人记忆及采用决策。

```mermaid
flowchart LR
  A[宿主提供任务、原方法和游戏经验] --> H[Harness² 提案与组合]
  H --> P[独立练习端 / 核心脚本沙箱]
  P --> E[真实位置、背包、生命与执行回执]
  E --> H
  H --> G[原版对照 + 未见场景复测]
  G --> M[现有方法版本库与游戏记忆]
  M --> A
  G --> R[宿主评审：保留原版或另行采用]
```

## 执行边界

宿主可按需注册具名练习环境。读取 `mc_practice({op:"help"})` 的 `environments` 可查当前支持的工况。对“地上有木头却选了挖方块”这类有原始失败回执的问题，先从方法库取回待改方法的精确 revision，再在原来的 `start` 参数中加入 `environment:"resource-acquisition"`。同一个候选会在掉落物和独立的方块场景各跑一次。两边开局已经有两块木头，评分要求背包再增加一块。按原作业 ID 收取 `result` 或 `compare` 后，宿主可以决定是否将该版本带到自然任务试用。

这个环境经 `MethodRunner` 执行候选源码，并通过核心的 `parseSteps` 解读 `mc.do`。确定性夹具模拟近处可达的单一掉落物或方块，只提供当前库存、可见掉落物和指定脚边格的读数。用已有地图记录回放移动时仍选 `caseIds`。包提供 `createResourceMethodPractice` 和 `harness2CognitionBrief`，后者将当前优化阶段要返回的文件、选项或经验格式显式交给宿主模型。

- `PracticeExecutionPort.binding` 必须显式声明专用实例与 realm；不得与源 Agent 的实例或 realm 相同。绑定由宿主确认，不是远端世界身份的密码学证明。
- 同一 Runner 只运行一个任务，RPC 在宿主串行执行。上游并行生成方案不意味着同时向一个身体发动作。专用服务端需要实现自身的控制租约、确定性场景恢复、观测和清理确认。
- `MethodPracticeExecutor` 使用现有 `MethodRunner` 沙箱和 `MethodLibrary` 的语法校验、不可变版本、原执行 UUID、回执及复盘。宿主必须向 `host.call` 提供真实适配器，`settle` 必须确认原动作和按键已释放。`mineflayer` 调用沿用 `{value:...}` 返回封装。
- reset、执行或清理失联后，该执行端被阻断，任务写入 `blocked`。不能通过重开程序、删账本或新建 ID 来重放未决动作；先核对原执行及隔离实例。崩溃留下的 `run.lock` 也需先确认原进程/任务终态，不能按时间自动删除。
- 实际动作通过核心已有能力执行，不给予候选 shell、文件、网络或模型权限。仅允许修改三个文件：`skills/minecraft-method/scripts/run.js`、`params.json`、`../SKILL.md`。系统说明、工具声明、安全约束及召回记忆不可改；不得增加插件或子 Agent。
- `SKILL.md` 保留 `name: minecraft-method` 的 frontmatter；描述和正文由 Agent 编辑。描述不要求匹配模板原文。源码、参数与指导文字分别按原有预算校验。

## 比较与采用

上游最终选择池只包含新方案。本集成另保留原版实测，并在模型没有见过的独立 fixture 上分别执行原版和选中方案。训练与复测 fixture 的 ID/snapshot 必须不同且环境版本一致。

首版目标支持到达指定位置、背包已知数量净增，附生命损失约束。独立采样位置/背包/生命，不相信程序自己返回的“成功”；缺失、过期、错实例、错 snapshot、未取得原执行 UUID或清理未知均不算成功。缺失物品键不是已知的零。

`gate.eligible=true` 只表示本组隔离对照至少一项成功率改善、原有成功项无退化且复测通过。未改善、证据不全或复测失败都保留原版。它不表示普遍提升或线上胜率，不证明战斗、生存、复杂任务拆解已学会。速度更快而成功结果相同，目前不会单凭耗时晋级。

`adopted` 始终为 `false`。`selectedReference` 指向练习作用域的方法版本，不能冒充源世界的方法引用。迁入源世界时需通过其现有方法库重新校验、保存，再按明确宿主策略审查原执行证据和 `expectedAdopted`；不覆盖运行中的程序，旧版及负例保留。

## Python 环境

上游使用 `fcntl`，需 Linux Python 3.12+；Windows 使用 WSL。显式安装可选依赖，不在游戏启动时自动安装：

```sh
uv venv --python 3.12 ~/.cache/mc-harness2/venv
uv pip install --python ~/.cache/mc-harness2/venv/bin/python -r /path/to/agent-mc-world/bridges/harness2/requirements.txt
~/.cache/mc-harness2/venv/bin/python /path/to/agent-mc-world/bridges/harness2/worker.py --check
```

不需要 `[render]`、OpenCode/Claude CLI、独立 API key。模型调用由宿主的 `model.generate` 处理。worker 校验安装版本及精确 Git 提交；editable 安装还检查跟踪源码未修改（兼容 Windows CRLF）。包内 worker 和 requirements 纳入构建哈希。

`worker` 显式设置 `command`、可选 `args`、可选 `script` 和 `workspace`。Linux 可使用独立 Python 绝对路径及默认 `harness2WorkerPath()`；WSL 的 command 为 `wsl`，args 为 `-d <发行版> --cd <Linux目录> --exec <Python路径>`，script 必须是 WSL 可读路径。没有 shell 插值。优先把 workspace 放在 Linux 本地文件系统，Windows 挂载盘会显著增加文件操作耗时。

## SDK 接入

`Harness2PracticeService` 从 `/learning` 提供显式后台入口。宿主注入原方法读取、当前身份、模型和隔离执行端后，`tool()` 返回可挂入 SDK/MCP 或 World 的公共 `mc_practice` 契约。`start` 需要原方法的精确版本，立即返回受理；`status` 只展开元数据，`result` 按需展开源码及原父版本。`cancel` 取消原任务，`close` 等待该任务退出；重启只读原账本，不恢复未决试跑。结果经过来源作用域校验。保存到源方法库、自然执行、复盘和采用仍走现有方法生命周期。

`parseHarness2ModelReply` 接受完整 JSON 制品；宿主必须提供能够返回完整源码的工具为空、仅游戏任务的后台模型通道。不要把短观察摘要接口用于代码编辑，也不要截断 JSON 或把完整私人会话交给优化器。取消信号应传回原模型请求。调用和缓存 token 没有回执时保持未知。

```js
import { Harness2Runner } from 'agent-mc-world/decisions';
import { createPhysicsMethodPractice, createPracticeGameMemory } from 'agent-mc-world/learning';

const practice = createPhysicsMethodPractice({
  directory: '/explicit/practice/methods', seeds: [1, 2],
  binding: { instanceId: 'lab-1', realm: 'practice', account: 'lab-bot', agent: 'my-agent', isolated: true },
});
// memoryPort.call routes to the host's EXISTING correctly scoped mc_memory tool.
const memory = createPracticeGameMemory(memoryPort);
const runner = new Harness2Runner({
  directory: '/explicit/practice/jobs', worker, model, practice: practice.executor,
  recall: memory.recall, remember: memory.remember,
});
const result = await runner.run({
  id: 'walk-revision-1', methodId: 'walk-method', sourceInstanceId: 'production-body',
  scope: { realm: 'production', account: 'my-account', agent: 'my-agent' },
  task: '游戏任务及公开 API 说明；仅放游戏资料', baseline,
  train: practice.fixtures[0], holdout: [practice.fixtures[1]], mode: 'parallel', k: 1,
  budget: { modelCalls: 6, trials: 6, wallMs: 180000, trialMs: 10000, contextBytes: 300000 },
}, abortSignal);
```

`baseline={code,params,guidance}` 应来自待改进的真实方法。`model={id, generate(request,signal)}` 返回结构化 `files`、匿名 `choice` 或 `experience:{cue,lesson,evidence,confidence}`；不能返回工具调用或以推理正文代替程序。`id` 应随模型路由/参数变化，宿主须遵守取消且不添加隐式重试。

自带 physics fixture 只有平地与碰撞物理，使用 Java 1.21.1 Prismarine、最多每次1000模拟 tick。`mc.state()` 返回 `snapshot.position` 与公开 `target`，支持 `bot.look`、`setControlState`、`clearControlStates`、`waitForTicks`；核心脚本仍有32调用上限。生命20、空背包是这个 fixture 的定义，不是从线上采到的数据。它不验证战斗、伤害、服务器规则、完整 Minecraft 场景复制或生产环境顺畅度。其他任务通过同一 `PracticeExecutionPort` 接入专用练习实例。

## 预算、账本与记忆

单模式常规需要 `4*k` 次练习、`3*k` 次提案/组合，`k>1` 多一次选择，另一次反思；每个留出场景增加原版与候选各一次执行。非法提案可能消耗更多预算。预算是模型调用数、执行次数、墙钟、单次方法时长及完整上下文 byte 数；不是 token 数或模型账单。超过上下文上限直接失败，不截断证据伪造完整输入。

任务 ID、完整配置、模型 ID、原方法、场景、作用域、召回经验及证据账本 UUID 共同绑定哈希。首次召回和账本 UUID 写入 `game-context.json`，恢复不重新召回而改变本次输入；另一份空账本不能误用之前的上游执行缓存。`journal.json` 保存次数、哈希、元数据、原执行及评审引用；重复 trial ID 返回原结果，已完成任务恢复不调用模型或身体，未完成任务不会自动续跑。更换配置用新任务 ID，并先处理原任务的未决效果。

`createPracticeGameMemory` 经现有 `mc_memory` 写入一次 `lesson`，标注隔离证据、原版对比和解释的限制，使用 jobHash 幂等检索。后续任务按需召回；不是无条件注入人格或扩大采用权限。记忆投递失败会保留 `memory:pending` 与完整结果，宿主可按 jobHash 显式重投 `memory.remember(result,signal)`，不得重跑练习来补记忆。上游 library 仅是当前任务的派生工作目录，可从方法/结果重建，不是新的权威记忆库。

元数据账本不记录宿主会话提示、回答、思考正文、聊天或凭据。独立工作目录会保存本次明确提供的游戏任务/召回经验、生成的方法源码/参数和结构化经验，这是可审查的方法产物，不是额外采集私人会话。不要把私人会话、角色资料或环境变量交给 model port。worker 不继承模型凭据。

## 只读实验可视化

`createHarness2Monitor({directory,jobs})` 从 `/decisions` 公开导出。传入明确允许展示的任务列表，复用一个 monitor 的 `snapshot()` 接入 `ClientConsolePort.experiments`，共享面板 `/#experiments` 显示过程和结果。每个宿主统一两秒采样，多个网页不增加文件读取；不会扫描目录、运行任务、调用模型或采用方法。

公开契约是 `agent-mc.experiments/v1`：阶段、调用与执行预算、输入/缓存/输出 token 与用量覆盖、实际试跑记录、基线/候选/留出观测、验证门槛及游戏记忆投递状态。只投影白名单元数据，不输出完整 journal、提示词、回答、思考正文、方法源码或凭据。缺失 token 保持 null，失败、未决效果与未达成目标分别显示。隔离试跑通过始终标注未在线采用。

运行账本五秒写入一次心跳，超过20秒没有更新的运行状态展示为未知，不能据此重放。在已完成记录里展示历史结果，不冒充当前运行状态。尚未开始的任务不伪造零用量。旧版没有 scope/心跳证据的 journal 保留为未知，不自动迁移或补跑。公开 projection 绑定已配置的 realm/account/agent 哈希。

默认面板禁止嵌入。宿主可显式允许精确的 loopback HTTP 或 `dsh-app://app` 桌面来源；CSP 仅放行该父页面，跨来源 API、控制 nonce、Host 与实例隔离检查保持启用。Java1.21.1 主维护，1.20.6 显式兼容构建。

## 目标与开销的共同评估

`mc_practice start` 默认 `objective: balanced`；显式 `success` 保留原来的严格成功率改进条件。两者都使用原始执行终态、重置后的场景与独立留出目标。balanced 也允许原本已成功的版本在保持各对目标与生命损失的前提下减少 SDK 调用，且必须在留出场景观察到减少。SDK 次数来自执行器原始 trace；脚本返回的数字不是测量。单次墙钟更快、未知开销、只在训练场景减少调用均不够。

`evaluatePracticeVariants` 通过 `/learning` 公开，比较同一 cohort 的质量和 SDK 工作量，提供非支配候选及 lite/balanced/quality 的建议。当前成本指标明确是 SDK 调用数，不冒充 token、金钱或真实 GPU 用量。时间作为辅助读数，缺失 token 保留 null。`Harness2Result.optimizationUsage` 分别记录本次优化本身的模型调用、试跑和已知 token；优化支出与未来实际复用节约分开。

`mc_practice {op:"compare",ids:["original-job","next-job"]}` 只读取指定已完成任务。对照绑定原方法父版本、参数、训练/留出场景、作用域和单次预算，跨 cohort 不推荐。比较不新增模型、试跑或采用；同一输入下多档建议也可能是同一版本。

可选文字复盘的格式或服务失败单独记录阶段和安全错误分类。已有候选继续执行独立留出评估，经验保持 null，不重试模型或已完成的身体试跑；优化用量缺失仍是未知。源码提案失败、任务取消/超时或未决身体效果仍按原契约停止，不采用同样的降级。

## 候选回写与后续复用

`mc_practice {op:"stage",id:"completed-job"}` 经宿主提供的 `createPracticeCandidateStager` 端口，将已通过隔离评估的源码重新语法校验，再按原父版本保存到原 `mc_script` 方法库。每次读取/保存都核对当前作用域；方法已被修订则先读新版本。原源码和已采用版本保持可检索，stage 不执行身体动作、不采用、不更新权重。已确认的保存会幂等返回原引用；保存回执未知时保留待核对状态，不能盲重试。校验或前置读失败不被标成已经写入。

随后仍由 Agent 读取候选适用条件，在自然任务执行精确引用，按原执行 UUID 和世界净变化 review/adopt；回退沿同一库选择旧引用。原始负面结果、隔离练习和真实任务证据分别保留。可选宿主 request-facts 只投递最近三项任务的短索引和按需入口，正文/源码/完整历史不常驻，不启动隐式模型循环。

本轮是方法层改进闭环和通用评估接口，尚未授权候选直接覆写运行中的引擎、上下文管理源码或工具契约。其他场景可经现有 `PracticeExecutionPort` 接入自己的真实重置/观察/清理与目标验证器；当前内置平地 fixture 仍不能验证潜水、战斗或背包。

设计参考：[HarnessPro 论文](https://arxiv.org/html/2610.26770v2)及其[公开产物仓库](https://github.com/pzs19/HarnessPro)。本实现复用已有方法库和执行证据，未移植其 Codex hook、固定工具次数或付费模型配置；论文基准收益不是 Minecraft 收益。

## 验证与回退

新增[多步骤合成最小实验](crafting-practice.md)：通过现有 MethodPracticeExecutor 执行受限参数策略，使用固定配方/库存 fixture 比较原版与两份留出。它是离线执行与验收链路测试，不是实际 Minecraft 服务端或自主生存提升证据；真实环境验收步骤见该文档。

默认单元测试不需要模型、Python或网络：`vitest run tests/harness2.test.ts`。设置 `HARNESS2_TEST_WORKER` 为 worker JSON 后，`tests/harness2-upstream.test.ts` 执行原版算法、实际物理、两个递归模式、反思及恢复检查，使用明确标记的确定性模型替身；它不证明真实 LLM 提升。

停用宿主的显式练习入口即可停止新任务；取消当前请求后仍须确认原清理终态。不要删除未知账本。源码回退用本提交的 `git revert`，包回退到先前锁定版本；线上采用始终另行操作，所以本集成没有替换当前线上方法或权重。
